// Entry point. The console UI is added in the next increment; for now this verifies
// that the database opens and the schema installs.
#include <exception>
#include <iostream>

#include "data/Database.hpp"

int main(int argc, char** argv) {
    const std::string dbPath = argc > 1 ? argv[1] : "lms.db";
    try {
        lms::data::Database db(dbPath);
        db.initialiseSchema();
        std::cout << "LMS database ready at " << dbPath << '\n';
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << '\n';
        return 1;
    }
}
